#ifndef LAB4_H
#define LAB4_H

#include "lab3pkg/lab3.h"




using Eigen::Vector4f; //float 4x4 matrix

std::vector<double> lab_invk(float xWgrip, float yWgrip, float zWgrip, float yaw_WgripDegree);

#endif
